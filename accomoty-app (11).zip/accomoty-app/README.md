# Accomoty — Web App

Your Accomoty React component, packaged as a real, runnable web app (Vite + React 18 + Tailwind CSS + lucide-react). Your original `App.jsx` code is unchanged.

## Run it locally

Requires [Node.js](https://nodejs.org) 18+.

```bash
npm install
npm run dev
```

Then open the URL Vite prints (usually http://localhost:5173).

## Build for production

```bash
npm run build
```

This outputs a static site to `dist/`, which you can host anywhere (Vercel, Netlify, Cloudflare Pages, GitHub Pages, or any static file host).

```bash
npm run preview   # preview the production build locally
```

## Deploy in one click

The `dist/` folder (or this whole repo) can be dragged straight into:
- **Netlify** — drag-and-drop the `dist` folder at app.netlify.com/drop
- **Vercel** — `npx vercel` from this folder (it auto-detects Vite)
- **Cloudflare Pages** — connect the repo, build command `npm run build`, output dir `dist`

## Project structure

```
accomoty-app/
├── index.html          # HTML entry point
├── src/
│   ├── main.jsx         # React root — mounts App
│   ├── App.jsx           # Your original Accomoty app (unchanged)
│   └── index.css         # Tailwind directives
├── tailwind.config.js
├── postcss.config.js
├── vite.config.js
└── package.json
```
